module.exports = {
  content: [
    "./public/index.html",
    "./src/**/*.{vue,js,ts}",
    "./src/components/**/*.{vue,js,ts}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}