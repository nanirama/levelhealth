const path = require("path")

exports.createPages = async ({ actions }) => {
  const { createPage } = actions
  createPage({
    path: "/using-dsg",
    component: require.resolve("./src/templates/using-dsg.js"),
    context: {},
    defer: true,
  })
}

// exports.createPages = async ({ graphql, actions }) => {
//   const { createPage } = actions
//   const result = await graphql(`
//   query {
//     allWpPost(sort: {order: DESC, fields: date}) {
//       edges {
//         node {
//           slug
//           title          
//         }
//       }
//     }
//   }
// `)



//   const data = [
//     ...result.data.allWpPost.edges
//   ];

//   for (const edge of data) {
//     let pageTemplate = path.resolve(`./src/templates/BlogTemplate.js`);
//     let slug = `/blog/${edge.node.slug}`;
//     createPage({
//       path: slug,
//       component: pageTemplate,
//       context: {
//         slug
//       },
//     });
//   }

// }