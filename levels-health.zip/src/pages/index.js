import * as React from "react"

import Layout from "../components/layout"
import Seo from "../components/seo"
import LatestPost from "../components/elements/LatestPost"


const IndexPage = () => (
  <Layout>
    <LatestPost/>
  </Layout>
)
export default IndexPage
