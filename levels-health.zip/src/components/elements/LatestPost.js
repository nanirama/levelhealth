import * as React from "react"
import { useStaticQuery, graphql } from "gatsby"

const LatestPost = () => {
    // const { LastPost } = useStaticQuery(
    //     graphql`
    //       query {
    //         LastPost : allWpPost(sort: {order: DESC, fields: date}, limit: 1) {
    //                 edges {
    //                 node {
    //                     id
    //                     slug
    //                     title
    //                     guid
    //                     date
    //                     featuredImage {
    //                     node {
    //                         localFile {
    //                         childImageSharp {
    //                             gatsbyImageData(layout: FULL_WIDTH)
    //                         }
    //                         }
    //                     }
    //                     }
    //                 }
    //                 }
    //             }
    //       }
    //     `
    // )
    // console.log('LastPost',LastPost)
    return (
        <h2>Latest Single Post</h2>
    )
}
export default LatestPost
