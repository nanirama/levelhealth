import React from "react"
import Layout from '../components/layout'
const Blog = (props) => {  
  return (
    <Layout>
       <h2>Blog Post Single Page</h2>
    </Layout>  
  )
}
export default Blog
